# 陈一剪辑 Skill · 风格库版

把口播原片剪成竖屏视频：自然气口、单行字幕、白黄标题、语义匹配B-roll、身份与AI标识，以及可复现的渲染源。

## 选风格

当前默认 **CY-001｜陈一经典口播**。打开 [带图风格索引](skills/chenyi-editing/styles/风格索引.md)，或在本地双击 `skills/chenyi-editing/styles/index.html`。文件夹同时显示编号、名称和效果图。新增风格依次登记 CY-002、CY-003，不伪造尚未实现的风格。

## 安装与前期准备

把 `skills/chenyi-editing` 整个文件夹复制到 agent 的技能目录，例如 Codex 的 `~/.codex/skills/chenyi-editing`。已有版本先备份。其他 agent 可直接读取 SKILL.md 并按相对链接加载参考文件。

准备 Python 3.10+、含 libass/libx264 的 FFmpeg、ffprobe、思源宋体 SC Heavy 字体、可访问的原片与素材文件夹。依赖安装、官方获取地址和能力边界见 [setup.md](skills/chenyi-editing/references/setup.md)。原片、素材、字体、模型和账号不随包分发。可选本地转写依赖单独安装。仅能聊天的 agent 无法执行视频渲染。

## 直接发给 agent

> 使用 chenyi-editing，风格 CY-001。原片：[我的原片路径]；素材库：[我的素材路径]；输出：[目录]；标题：[标题]。保留原口播，先核对实际音频再剪长空白，保留自然气口；匹配丰富且尽量不重复的B-roll。沿用我已确认的身份和AI标识。默认交付MP4、字幕和渲染源；需要剪辑台时我会另说。缺素材可在我授权的来源搜索下载，保存出处。

## 执行入口

在技能目录运行：
```text
python -m pip install -r requirements.txt
python scripts/style_registry.py list
python scripts/init_project.py --source "/media/原片.mp4" --project "/work/新片" --font "/fonts/SourceHanSerifSC-Heavy.otf" --style-id CY-001 --title-top "标题第一行" --title-bottom "标题第二行"
```
初始化后仍需转写、校对、听审气口和匹配素材；SKILL.md给出执行顺序。脚本会输出真实MP4/ASS/SRT，JSON渲染源可以修改后重渲染，并非ChatCut或剪映原生工程。需要可视化剪辑台时使用接收方自己的官方工具连接。

## 复现与验证

风格规则可以复用；不同素材和模型不保证逐像素一致。切点须依据真实声音，不能听音时明确标待审。包内 smoke_test.py 使用合成视频检查同步裁切、时间映射、字幕与渲染，不能替代真人听审。验证状态见技能 references/validation.md。

分享包不含用户原片、真人预览、个人机器路径或登录信息。公开仓库不代表第三方素材许可随包转让。
